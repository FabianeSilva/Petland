package com.petland;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetlandApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
