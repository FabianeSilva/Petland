package com.petland;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetlandApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetlandApiApplication.class, args);
	}

}
